import{a as t}from"../chunks/entry.3DRfMHXq.js";export{t as start};
