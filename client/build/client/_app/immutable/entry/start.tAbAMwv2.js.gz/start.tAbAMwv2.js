import{a as t}from"../chunks/entry.BsdivZpL.js";export{t as start};
