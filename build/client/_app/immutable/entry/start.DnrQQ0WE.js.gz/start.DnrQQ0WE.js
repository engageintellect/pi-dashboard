import{a as t}from"../chunks/entry.BGFA3Vdj.js";export{t as start};
