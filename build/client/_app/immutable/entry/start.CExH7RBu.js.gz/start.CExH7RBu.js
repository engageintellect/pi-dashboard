import{a as t}from"../chunks/entry.69o0Rul2.js";export{t as start};
