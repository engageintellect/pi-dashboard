import{a as t}from"../chunks/entry.ZTbG9Lxr.js";export{t as start};
