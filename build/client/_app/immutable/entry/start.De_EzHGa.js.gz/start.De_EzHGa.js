import{a as t}from"../chunks/entry.CiO8vg00.js";export{t as start};
